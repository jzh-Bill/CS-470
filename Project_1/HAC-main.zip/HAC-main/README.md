# HAC
Please see "BD Protocol.pdf" for documentation
